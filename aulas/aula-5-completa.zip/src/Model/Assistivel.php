<?php

namespace Alura\Solid\Model;

interface Assistivel
{
    public function assistir(): void;
}
